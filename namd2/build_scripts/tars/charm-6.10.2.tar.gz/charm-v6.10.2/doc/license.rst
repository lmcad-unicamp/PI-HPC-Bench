========================
Charm++/Converse license
========================

.. include:: ../LICENSE
