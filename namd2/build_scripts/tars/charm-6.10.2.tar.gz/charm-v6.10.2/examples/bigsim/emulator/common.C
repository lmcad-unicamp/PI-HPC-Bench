#include <stdio.h>

void traceWriteSTS(FILE *, int) {

}
