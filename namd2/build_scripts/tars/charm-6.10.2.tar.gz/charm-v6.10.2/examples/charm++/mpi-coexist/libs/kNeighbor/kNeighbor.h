//interface for invocation from MPI
void kNeighbor(int numchares, int numsteps, int msgsize, int lbfreq);

