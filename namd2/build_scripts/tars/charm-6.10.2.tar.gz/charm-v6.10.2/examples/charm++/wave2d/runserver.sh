#!/bin/sh
echo "Starting up server:"
./charmrun +p4 ./wave2d ++server ++server-port 1234
echo "Server Exited"

