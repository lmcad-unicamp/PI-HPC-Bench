#ifndef HELLO_H_
#define HELLO_H_
#include <cstdint>

void hello(const uint64_t n, int process);

#endif // HELLO_H_
