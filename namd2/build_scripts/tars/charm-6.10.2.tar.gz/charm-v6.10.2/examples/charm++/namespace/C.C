#include "C.h"

C::C() {}
C::C(CkMigrateMessage *m) {}
void C::quit() { CkExit(); }

#include "C.def.h"
